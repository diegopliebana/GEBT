#!/bin/bash
#./GE-noAstar-slide -p 500 -g 42 -x .5 -w .5 -a 2 -m 1 -M 1 -n 2 -e .02 -F noAstar-slide-$1 -G noAstar-01.bnf -d 20 -D 30 -S $1 0 100
./GE-noAstar-slide -p 500 -g 84 -x .5 -w .5 -a 2 -m 1 -M 1 -n 2 -e .02 -F noAstar-slide-$1 -G noAstar-01.bnf -d 20 -D 30 -S $1 0 100


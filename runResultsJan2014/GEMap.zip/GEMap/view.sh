if [[ -z "$2" ]] ; then
	echo "USAGE: $0 BT-file rndseed"
	exit;
fi;
echo "../benchmark_0_1_5/MarioAI+Benchmark && java -classpath 'out/production' grammaticalbehaviors.GEBT_Mario.EvoMain -tl 100 -ld 0 1 2 3 4 -lt 0 1 -ll 320 -ce 1 -vis 1 -fps 50 -rnd $2 -if ../../GEMap/$1 -of ../../GEMap/viewfitness.txt"
cd ../benchmark_0_1_5/MarioAI+Benchmark && java -classpath "out/production" grammaticalbehaviors.GEBT_Mario.EvoMain -tl 100 -ld 0 1 2 3 4 -lt 0 1 -ll 320 -ce 1 -vis 1 -fps 50 -rnd $2 -if ../../GEMap/$1 -of ../../GEMap/viewfitness.txt


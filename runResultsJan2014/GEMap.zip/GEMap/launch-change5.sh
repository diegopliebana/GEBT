#!/bin/bash
#./GE-change5 -p 500 -g 25 -x .5 -w .5 -a 2 -m 1 -M 1 -n 2 -e .02 -F marioxp-change5-$1 -G aStar-01.bnf -d 20 -D 30 -S $1 0 100
./GE-change5 -p 500 -g 50 -x .5 -w .5 -a 2 -m 1 -M 1 -n 2 -e .02 -F marioxp-change5-$1 -G aStar-01.bnf -d 20 -D 30 -S $1 0 100

